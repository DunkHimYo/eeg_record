from .emotiv_cortex2_client import EmotivCortex2Client

__all__ = [
'EmotivCortex2Client'
]

# Version 1.0.0

﻿
using UnityEngine;
using UnityEngine.UI;


namespace dirox.emotiv.controller
{
    public class HeadsetGroup: BaseCanvasView
    {
    }
}
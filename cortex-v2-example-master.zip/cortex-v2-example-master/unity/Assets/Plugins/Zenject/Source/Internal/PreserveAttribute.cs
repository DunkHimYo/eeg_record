using System;

namespace ModestTree.Util
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class PreserveAttribute : Attribute
    {
    }
}
